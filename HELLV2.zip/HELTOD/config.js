//apikey bisa beli langsung ke dev xteam/bisa beli lewat perantara Fernazer
//disini jangan di apa2 in dlu takutnya eror soalnya msih tes
tes = 'KurrXd' //apikey nya beli sendiri
tes = 'KurrXd' // hem
tes = 'KurrXd' // hem
  // name: 'https://website'
  nrtm: 'https://Fernazer.herokuapp.com',
  slurPunten: 'https://Fernazer.slurPunten.xyz'
}
global.APIKeys = { // APIKey woy tes
  // 'https://website': 'apikey'
  'https://api.xteam.xyz': 'tesdoang' // untuk keseluruhan fitur
})
tes_doang = 'SC By Helga Botz, SC Numpang Jan Sok Kras Dah Elu'
}