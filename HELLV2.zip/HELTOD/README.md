##CARA INSTALL MELALUI GIT

> pkg install git
> gitclone https://github.com/Fernazer
> cd Fernazer
> bash install.sh
> npm start
> scan qr

##CARA INSTALL

> termux-setup-storage [Y]
> cd /sdcard
> cd -r (namafile) /$HOME
> cd (namafile)
> bash install.sh 
> npm start
> Now scan the QR
